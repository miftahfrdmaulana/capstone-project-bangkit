package com.dicoding.gardenguard.ui.diagnose

class ResultViewModel {
}